package com.example.pcRoom.service;

import com.example.pcRoom.dto.UsersDto;
import com.example.pcRoom.entity.Users;
import com.example.pcRoom.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UsersRepository usersRepository;

    public void insertCoin(String userId, int amount) {
        Optional<Users> usersOptional = usersRepository.findById(userId);
        usersOptional.ifPresent(users -> {
            // 사용자가 존재하는 경우에만 로직을 수행합니다.
            int money = users.getMoney();
            users.setMoney(money + amount);
            usersRepository.save(users);});
        if (usersOptional.isEmpty()) {
            throw new IllegalArgumentException("사용자를 찾을 수 없습니다.");
        }
    }
}
